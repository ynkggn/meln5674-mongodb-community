# To Do List

* Make the UI not hideous
* Switch to non-legacy input controls
* More test datasets and queries
* Add "debounce" to query editor so query doesn't fire on every keystroke
* Support query variables
* Support optional fields
* Schema inference
* Schema backtracking
* Translate integration test job to use python requests isntead of curl, parse and verify output
